import utils
from utils import average
from utils import build_username as make_user
import utils as u
from utils import make_student, add_bonus, with_bonus
from utils import make_course, add_vat, build_username


def print_student_card(name, group, year):
    """Tələbə kartını üç sətirdə çap edir."""
    print("Name: " + name)
    print("Group: " + group)
    print("Year: " + str(year))


# Tapşırıq 1
print_student_card("Aysel Mammadova", "CE-101", 1)
print_student_card(year=2, name="Kamran Aliyev", group="CE-201")
# print_student_card("Aysel", "CE-101")

# Tapşırıq 2
print(add_vat(100))
print(add_vat(50, 10))
print(add_vat(vat_percent=5, price=80))

# Tapşırıq 3
print(build_username("Aysel", "Mammadova"))
print(build_username("Kamran", "Aliyev", 2005))

# Tapşırıq 4
print(make_student("Kamran", 61, "CE-101"))
students = []
while True:
    name = input("Name (quit to stop): ")
    if name == "quit":
        break
    score = int(input("Score: "))
    students.append(make_student(name, score))
for student in students:
    print(student["name"] + ": " + str(student["score"]))

# Tapşırıq 5
scores = [70, 95, 88, 100]
print(with_bonus(scores, 10))
print(scores)
add_bonus(scores[:], 10)
print(scores)
add_bonus(scores, 10)
print(scores)

# Tapşırıq 6
print(average(70, 80, 90))
print(average(100))
print(average())
print(make_course("CE101", title="Fundamentals of Programming", credits=6))

# Tapşırıq 7
print(utils.add_vat(200))
print(average(60, 70))
print(make_user("Nigar", "Hasanova"))
print(u.with_bonus([50, 95], 10))
