def add_vat(price, vat_percent=18):
    """Qiymətə ƏDV əlavə edib yeni qiyməti qaytarır."""
    return price + price * vat_percent / 100


def build_username(first, last, year=""):
    """first.last formatında istifadəçi adı qaytarır."""
    username = first.lower() + "." + last.lower()
    if year:
        username = username + str(year)
    return username


def add_bonus(scores, bonus):
    """Listi yerində dəyişir: hər bala bonus əlavə edir (max 100)."""
    for i in range(len(scores)):
        scores[i] = min(scores[i] + bonus, 100)


def with_bonus(scores, bonus):
    """Bonuslu yeni list qaytarır, orijinal dəyişmir."""
    new_scores = []
    for score in scores:
        new_scores.append(min(score + bonus, 100))
    return new_scores


def average(*numbers):
    """Verilən ədədlərin orta qiymətini qaytarır, boşdursa 0."""
    if not numbers:
        return 0
    return sum(numbers) / len(numbers)


def make_course(code, **details):
    """Kurs haqqında dictionary qaytarır."""
    course = {"code": code}
    for key, value in details.items():
        course[key] = value
    return course


def make_student(name, score, group=""):
    """Tələbə dictionary-si qaytarır."""
    student = {"name": name, "score": score}
    if group:
        student["group"] = group
    return student
