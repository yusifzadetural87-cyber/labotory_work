from utils import make_student


def add_student(students, name, score):
    """Tələbəni listə əlavə edir."""
    students.append(make_student(name, score))


def average_score(students):
    """Orta balı qaytarır, list boşdursa 0."""
    if not students:
        return 0
    total = 0
    for student in students:
        total += student["score"]
    return total / len(students)


def top_student(students):
    """Ən yüksək ballı tələbəni qaytarır, list boşdursa None."""
    if not students:
        return None
    best = students[0]
    for student in students:
        if student["score"] > best["score"]:
            best = student
    return best


def print_report(students):
    """Hesabatı çap edir."""
    for student in students:
        print(student["name"] + ": " + str(student["score"]))
    print("Average: " + str(average_score(students)))
    best = top_student(students)
    if best:
        print("Top student: " + best["name"] + " (" + str(best["score"]) + ")")


students = []
while True:
    print("1 Add student, 2 Report, 3 Quit")
    choice = input("Choice: ")
    if choice == "1":
        name = input("Name: ")
        score = int(input("Score: "))
        add_student(students, name, score)
    elif choice == "2":
        print_report(students)
    elif choice == "3":
        break
    else:
        print("Invalid choice, try again.")
